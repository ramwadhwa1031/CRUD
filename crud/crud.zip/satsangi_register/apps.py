from django.apps import AppConfig


class SatsangiRegisterConfig(AppConfig):
    name = 'satsangi_register'
